<?php
if(move_uploaded_file($_FILES["myfile"]["tmp_name"], "./files/".$_FILES["myfile"]["name"])){
	echo "File uploaded successfully!";
} else{
	echo "Upload faild!";
}
?>