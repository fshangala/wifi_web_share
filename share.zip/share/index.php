<!DOCTYPE html>
<html lang="en">
<head>
  <title>WiFi Web Share</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
  <script>
            $(function () {
                $('#btn').click(function () {
                    $('.myprogress').css('width', '0');
                    $('.msg').text('');
                    var myfile = $('#myfile').val();
                    var formData = new FormData();
                    formData.append('myfile', $('#myfile')[0].files[0]);
                    $('#btn').attr('disabled', 'disabled');
                    $('.msg').text('Uploading in progress...');
                    $.ajax({
                        url: 'uploadscript.php',
                        data: formData,
                        processData: false,
                        contentType: false,
                        type: 'POST',
                        // this part is progress bar
                        xhr: function () {
                            var xhr = new window.XMLHttpRequest();
                            xhr.upload.addEventListener("progress", function (evt) {
                                if (evt.lengthComputable) {
                                    var percentComplete = evt.loaded / evt.total;
                                    percentComplete = parseInt(percentComplete * 100);
                                    $('.myprogress').text(percentComplete + '%');
                                    $('.myprogress').css('width', percentComplete + '%');
                                }
                            }, false);
                            return xhr;
                        },
                        success: function (data) {
                            $('.msg').html(data);
                            $('#btn').removeAttr('disabled');
                        }
                    });
                });
            });
    </script>
</head>
<body>

<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <!-- Brand/logo -->
  <a class="navbar-brand" href="#">WiFi Web Share</a>
  
  <!-- Links -->
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" onclick="load_file('*')" href="#display">All files</a>
    </li>
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
        Videos
      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" onclick="load_file('mp4')" href="#display">MP4</a>
        <a class="dropdown-item" onclick="load_file('mkv')" href="#">MKV</a>
      </div>
    </li>
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
        Images
      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" onclick="load_file('jpg')" href="#display">JPG</a>
        <a class="dropdown-item" onclick="load_file('png')" href="#">PNG</a>
        <a class="dropdown-item" onclick="load_file('gif')" href="#">GIF</a>
      </div>
    </li>
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
        Documents
      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" onclick="load_file('pdf')" href="#display">PDF</a>
        <a class="dropdown-item" onclick="load_file('docx')" href="#">DOCX</a>
      </div>
    </li>
  </ul>
</nav>
<hr>
<div class="container">
	<form action="uploadscript.php">
		<div class="form-group">
      		<input type="file" class="form-control-file border" id="myfile" name="myfile">
    	</div>
    	<div class="form-group">
            <div class="progress">
                <div class="progress-bar progress-bar-success myprogress" role="progressbar" style="width:0%">0%</div>
            </div>
            <div class="msg"></div>
        </div>
        <div class="form-group">
        	<button id="btn" class="btn btn-info">Upload</button>
        </div>
	</form>
</div>
<div id="display" class="container">
  <h2>Files</h2>
  <div id="list_files" class="container"></div>
</div>

<script type="text/javascript">
	$("document").ready(function(){
    $("#list_files").html("<div class='spinner-border text-primary'></div>");
		$("#list_files").load("files/fetch_files.php");
	});
  function load_file(type) {
    $("#list_files").html("<div class='spinner-border text-primary'></div>");
    $("#list_files").load("files/fetch.php?file_type="+type);
  }
  function delete_file(myfile) {
		$.post(
			"delete_file.php",
			{filename: myfile},
			function(data){
				alert(data);
        $("#list_files").html("<div class='spinner-border text-primary'></div>");
				$("#list_files").load("files/fetch_files.php");
			}
		);
	}
</script>
</body>
</html>