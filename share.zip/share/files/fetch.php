<?php
$type = $_GET["file_type"];
$files = glob("*.$type");
echo "<ul class='nav flex-column hover'>";
foreach($files as $file){
	if ($file=="fetch_files.php" or $file=="fetch.php") {
		echo "";
	} else{
	echo "<li class='nav-item'>";
	echo "<span>$file</span>";
	echo " ";
	echo "<a class='btn btn-success' href='files/$file'>Download</a>";
	echo " ";
	echo "<button onclick='delete_file(\"$file\")' class='btn btn-danger'>Delete</button>";
	echo "</li><br>";
	}
}
echo "</ul>";
?>